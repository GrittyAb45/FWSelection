module.exports = {
  dbURL : "mongodb+srv://abhay:jonsnow1@cluster0-lqilb.mongodb.net/DucksFeed?retryWrites=true",
  dbLocal: "mongodb://localhost:27017/DucksFeed"
}
