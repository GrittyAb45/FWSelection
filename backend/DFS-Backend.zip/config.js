module.exports = {
  dbURL : "mongodb+srv://abhay:8WJubO6ttjHGMd8R@cluster0-cyugp.mongodb.net/test?retryWrites=true"
}
